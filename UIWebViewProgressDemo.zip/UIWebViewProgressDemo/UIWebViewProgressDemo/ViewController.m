//
//  ViewController.m
//  UIWebViewProgressDemo
//
//  Created by 李秋 on 2018/5/30.
//  Copyright © 2018年 baidu. All rights reserved.
//

#import "ViewController.h"
#define SCREENW self.view.frame.size.width
#define SCREENH self.view.frame.size.height
#define font_14 14.0
@interface ViewController ()<UIScrollViewDelegate,UIWebViewDelegate>

@property(nonatomic,strong)UIWebView *webView;
@property(nonatomic,strong)UIButton *updateBtn;
@property(nonatomic,strong)UIProgressView *progressView;//加载进度条
@property(nonatomic,assign)BOOL isLoadFinish;//是否加载完成
@property(nonatomic,strong)NSTimer *timer;//定时器
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupNav];
    _webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 64, SCREENW, SCREENH)];
    _webView.backgroundColor = [UIColor whiteColor];
    _webView.delegate = self;
    _webView.scrollView.contentInset = UIEdgeInsetsMake(0, 0, 93, 0);
    NSURL* urlAddress = [NSURL URLWithString:@"https://www.baidu.com"];
    NSURLRequest* request = [NSURLRequest requestWithURL:urlAddress];
    [_webView loadRequest:request];
    [self.view addSubview:_webView];
    [self initSetBtn];
}


- (void)setupNav
{
    UIView *bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREENW, 64)];
    bgView.backgroundColor = [UIColor lightGrayColor];
    [self.view addSubview:bgView];
    //    1.标题
    UILabel* titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(SCREENW*0.5-100, 22, 200, 40)];
    titleLabel.textColor = [UIColor grayColor];
    titleLabel.font = [UIFont systemFontOfSize:17.0];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [bgView addSubview:titleLabel];
    //    2.返回
    UIButton* backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backButton.frame = CGRectMake(0, 30, 41, 30);
    [backButton setImage:[UIImage imageNamed:@"nav_fanhui"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(backToHome) forControlEvents:UIControlEventTouchUpInside];
    [bgView addSubview:backButton];

    //进度条
    _progressView = [[UIProgressView alloc] initWithFrame:CGRectMake(0, bgView.bounds.size.height -2, bgView.bounds.size.width, 2)];
    _progressView.progressTintColor = [UIColor greenColor];
    _progressView.trackTintColor = [UIColor whiteColor];
    [bgView addSubview:_progressView];
}

//前进 后退 刷新 取消
-(void)initSetBtn{
    UIView *bageView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREENH - 30, SCREENW, 30)];
    bageView.backgroundColor = [UIColor whiteColor];
    bageView.alpha = 0.9;
    [self.view addSubview:bageView];
    //顶线
    UIView *topLineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREENW, 0.5)];
    topLineView.backgroundColor = [UIColor grayColor];
    [bageView addSubview:topLineView];
    //前进
    UIButton *goBtn = [[UIButton alloc] initWithFrame:CGRectMake(SCREENW*0.25, 0, SCREENW*0.25, 30)];
    [goBtn setImage:[UIImage imageNamed:@"hou"] forState:UIControlStateNormal];
    goBtn.titleLabel.font = [UIFont systemFontOfSize:font_14];
    [goBtn addTarget:self action:@selector(goBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [bageView addSubview:goBtn];
    //后退
    UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, SCREENW*0.25, 30)];
    [backBtn setImage:[UIImage imageNamed:@"qian"] forState:UIControlStateNormal];
    backBtn.titleLabel.font = [UIFont systemFontOfSize:font_14];
    [backBtn addTarget:self action:@selector(backBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [bageView addSubview:backBtn];
    //刷新
    _updateBtn = [[UIButton alloc] initWithFrame:CGRectMake(SCREENW*0.5, 0, SCREENW*0.25, 30)];
    [_updateBtn setImage:[UIImage imageNamed:@"xin"] forState:UIControlStateNormal];
    _updateBtn.titleLabel.font = [UIFont systemFontOfSize:font_14];
    [_updateBtn addTarget:self action:@selector(updateBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [bageView addSubview:_updateBtn];
    //取消
    UIButton *cancelBtn = [[UIButton alloc] initWithFrame:CGRectMake(SCREENW*0.75, 0, SCREENW*0.25, 30)];
    [cancelBtn setImage:[UIImage imageNamed:@"guan"] forState:UIControlStateNormal];
    cancelBtn.titleLabel.font = [UIFont systemFontOfSize:font_14];
    [cancelBtn addTarget:self action:@selector(cancelBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [bageView addSubview:cancelBtn];
}



- (void)backToHome
{
    if (self.webView.canGoBack) {
        [self.webView goBack];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}
//前进
-(void)goBtnClick{
    if (self.webView.canGoForward) {
        [self.webView goForward];
    }
}
//后退
-(void)backBtnClick{
    [self backToHome];
}
//刷新
-(void)updateBtnClick{
    [UIView animateWithDuration:0.3 animations:^{
        [_updateBtn setTransform:CGAffineTransformRotate(_updateBtn.transform, M_PI)];
    }];
    [self.webView reload];
}
//取消
-(void)cancelBtnClick{
    if (self.webView.loading) {
        [self.webView stopLoading];
    }
}
//UIWebViewDelegate
-(void)webViewDidStartLoad:(UIWebView *)webView{
    _progressView.progress = 0;
    _isLoadFinish = NO;
    _timer = [NSTimer scheduledTimerWithTimeInterval:0.01667 target:self selector:@selector(timerCallback) userInfo:nil repeats:YES];
    
}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    _isLoadFinish = YES;
}
-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    
}
-(void)timerCallback {
    if (_isLoadFinish) {
        if (_progressView.progress >= 1) {
            _progressView.hidden = true;
            [_timer invalidate];
        }else {
            _progressView.progress += 0.1;
        }
    }else {
        _progressView.progress += 0.05;
        if (_progressView.progress >= 0.95) {
            _progressView.progress = 0.95;
        }
    }
}
-(void)dealloc{
    NSLog(@"相关页面销毁了");
    //清楚cookies
    NSHTTPCookie *cookie;
    NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (cookie in [storage cookies])
    {
        [storage deleteCookie:cookie];
    }
    //清除UIWebView的缓存
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
}

@end
